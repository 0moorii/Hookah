# Hookah Manager command help

Public entrypoint: **Hookah-Manager.exe** (Windows, version 1.0.0).

```text
.\Hookah-Manager.exe setup                       Install the private Python environment
.\Hookah-Manager.exe setup --snmp-bin PATH       Set the Net-SNMP executable directory
.\Hookah-Manager.exe doctor                      Check dependencies and tool paths
.\Hookah-Manager.exe --version                   Print the application version
.\Hookah-Manager.exe --help                      Print this guide
.\Hookah-Manager.exe                            Open the interactive terminal menu
.\Hookah-Manager.exe help capture                Explain a specific command
.\Hookah-Manager.exe config show                 Show resolved config.json settings
.\Hookah-Manager.exe get --oid .1.3.6.1.2.1.1.1.0
.\Hookah-Manager.exe walk --oid .1.3.6.1.2.1.2.2.1.2 --output interfaces.csv
.\Hookah-Manager.exe browse --group memory
.\Hookah-Manager.exe mib --group storage          Show an offline MIB tree
.\Hookah-Manager.exe catalog                     List available OID choices
.\Hookah-Manager.exe capture --oid .1.3.6.1.2.1.25.3.3.1.2 --duration 10 --output cpu.csv
.\Hookah-Manager.exe plot cpu.csv --output plots/cpu.png --no-show
.\Hookah-Manager.exe compare before.csv after.csv --output comparison.png
.\Hookah-Manager.exe keys generate --directory keys
```

Connection options: `--target udp:host:port`, `--community VALUE`,
`--version {1,2c}`, `--timeout SECONDS`, `--retries {0..10}`,
`--encryption-config PATH`, `--snmp-bin PATH`, and `--config PATH`.
`--no-config` ignores the profile and requires a target for network operations.
At the top level, `--version` is the Hookah version; after a network command,
it selects the SNMP protocol version.

Capture options: `--interval SECONDS`, `--duration SECONDS`, `--sync-agent`,
`--counter-bits {auto,32,64}`, and required `--output PATH`.
Use WALK to discover the actual interface index before capturing counters.

Plot options: `--output PATH`, `--color COLOR`, `--scale {auto,linear,symlog}`,
`--memory-mode {used,percent,both}`, `--no-show`, and `--show`.
Comparison accepts `--label-first`, `--label-second`, `--title`, and memory
modes `used` or `percent`. Output directories are created automatically.

Authorized SNMP SET:

```text
.\Hookah-Manager.exe set --community lab-write --oid .1.3.6.1.2.1.1.6.0 --type s --value "Lab room 2"
```

Exit codes: 0=success, 1=runtime error, 2=usage error, 130=Ctrl+C.
Python 3.10+ is required for runtime and setup; Net-SNMP clients are required for
network operations. Every implementation/support file is under `.hookah/`.
