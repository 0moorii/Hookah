# Hookah Agent command help

Public entrypoint: **Hookah-Agent.exe** (Windows, version 1.0.0).

```text
.\Hookah-Agent.exe setup                       Install private Python dependencies
.\Hookah-Agent.exe --version                   Print the application version
.\Hookah-Agent.exe --help                      Print this guide
.\Hookah-Agent.exe                            Start the foreground Agent
.\Hookah-Agent.exe config show                 Show the adjacent config.json
.\Hookah-Agent.exe config set --sample-interval 10
.\Hookah-Agent.exe config set --interval ifInOctets 120
.\Hookah-Agent.exe config set --clear-interval ifInOctets
.\Hookah-Agent.exe --config profiles/lab.json   Start with another configuration
.\Hookah-Agent.exe --port 1161 --manager 192.168.1.10
.\Hookah-Agent.exe --list-oids                  Inspect local metrics without listening
.\Hookah-Agent.exe mib --group memory --values
.\Hookah-Agent.exe help config set             Show every configuration option
```

Intervals are finite positive numbers in seconds. Configuration updates validate
before replacing the file, and sampling changes apply to a running Agent.
The default profile listens on UDP 1161 and permits loopback only.

Remote configuration uses the same interface:

```text
.\Hookah-Agent.exe config show --remote udp:192.168.1.20:1161 --community public
.\Hookah-Agent.exe config set --remote udp:192.168.1.20:1161 --community lab-write --interval cpu 10
```

Remote writes require the enabled write community and an allowed source IP.
Optional `--encryption-config PATH` selects an encrypted remote transport profile.

Windows service installation (administrator PowerShell):

```text
.\Hookah-Agent.exe service install -ManagerAddresses 192.168.1.10/32 -Port 1161
.\Hookah-Agent.exe service uninstall
```

Python 3.10+ is required for runtime and setup. All setup and implementation files
are kept in `.hookah/`; the public commands manage the adjacent `config.json`.
Detailed MIB, encryption, Linux/systemd, and Windows service guides are under
`.hookah/docs/` and `.hookah/platform/`.
